//import liraries
import React, { Component } from 'react';
import { View, Text, StyleSheet, KeyboardAvoidingView, TextInput, TouchableOpacity, Image, ScrollView, FlatList } from 'react-native';
import RazorpayCheckout from 'react-native-razorpay';
import StateListing from '@components/StateListing';
import {
    Container,
    ActionSheet,
    Icon,
    Content,
    Left,
    Button,
    Body,
    Right,
    Title,
    Toast,
    Item,
    CheckBox,
    ListItem,
} from 'native-base';
import {
    postApiRequest,
    showToast,
    setItem,
    postApiRequestWithHeaders,
    errorHandler,
} from '../../common/user';
import moment from 'moment';
import HeaderComponent from '@components/HeaderComponent';
import DatePicker from 'react-native-datepicker';
import { colors, constant, data } from '../../common/index';
import styles from './styles';
import Spinner from 'react-native-loading-spinner-overlay';
// create a component
var Gender = ["Male", "Female", "Others", "Cancel"];
var CANCEL_INDEX = 3;
const default_user = require('../../assets/imgs/default_user.png');
const calendar = require('../../assets/imgs/calendar.png');
import Camera from '@components/Camera';
import { setMember } from "../../actions"
import { connect } from "react-redux";
import Geolocation from '@react-native-community/geolocation';
import { check, PERMISSIONS, RESULTS, request } from 'react-native-permissions';


class AvailableRMP extends Component {
    onEndReachedCalledDuringMomentum;
    constructor(props) {
        super(props);
        this.state = {
            spinner: false,
            resulted_rmp: this.props.route.params.resulted_rmp.resulted_doctors,
            selectedDoctor: {},
            vLat: '30.7162',
            vLng: '76.7776',
            iCurrentPage: this.props.route.params.resulted_rmp.iCurrentPage,
            iMaxPages: this.props.route.params.resulted_rmp.iMaxPages,

        };
    }

    componentDidMount() {
        Geolocation.getCurrentPosition(info => {
            console.log(info, "current");
            this.setState({
                vLat: String(info.coords.latitude),
                vLng: String(info.coords.longitude)
            })
        }, error => {
            console.log("location error", error);
            this.setState({
                vLat: "30.7162",
                vLng: "76.7776"
            })
            if (error.PERMISSION_DENIED == 1) {
                console.log("denianle")
                request(PERMISSIONS.ANDROID.ACCESS_FINE_LOCATION);
            }
        });
    }


    navigator = (action, data) => {
        console.log(action, data, "callback");
        switch (action) {
            case "back":
                console.log(this.state);
                this.props.navigation.goBack();
                break;
            case "book":
                console.log(data);
                this.setState({ selectedDoctor: data });
                console.log(this.state, "booking.....");
                console.log(parseInt(data.fFirstConsultFee) * 100, "fee in int")
                this.startPayment(String(parseInt(data.fFirstConsultFee) * 100));
                //    this.props.navigation.goBack();
                break;
            default:
                break;
        }
    }

    startPayment = (fees) => {
        var options = {
            description: 'Appointment Consultation Fees',
            image: 'https://www.talktomedic.in/assets/web/images/ic_launcher.png',
            currency: 'INR',
            // key: 'rzp_test_tcd4Yy6Q8OlCde',
            key: 'rzp_live_OD0kknoemJXCtm',
            amount: fees,
            name: this.props.user_data.vFirstName,
            prefill: {
                email: '',
                contact: this.props.user_data.vMobileNo,
                name: this.props.user_data.vFirstName + ' ' + this.props.user_data.vLastName
            },
            theme: { color: '#066DAE' },
            payment_capture: 1
        }
        console.log(options, "optins...")
        RazorpayCheckout.open(options).then((data) => {
            // handle success
            console.log(data, "payment succcsess");
            this.bookAppointment(data.razorpay_payment_id)
            //  alert(`Success: ${data.razorpay_payment_id}`);
        }).catch((error) => {
            // handle failure
            console.log(error, "payment succcserroress")
            //  alert(`Error: ${error.code} | ${error.description}`);
        });
    }


    bookAppointment = (id) => {
        console.log(this.state, "booking.....");
        console.log("book app", id);
        var param = {
            vTransactionId: id,
            iUserId: this.state.selectedDoctor.iUserId,
            iAvailabilityId: this.state.selectedDoctor.iAvailabilityId,
            treatments: this.props.appt_data.treatments,
            eType: this.props.appt_data.eType,
            ePurpose: this.props.appt_data.ePurpose,
            eMode: this.props.appt_data.eMode,
            dTime: this.props.appt_data.dTime,
            dScheduledDate: this.props.appt_data.dScheduledDate,
            iFamilyMemberId: this.props.appt_data.iFamilyMemberId == "MySelf" ? null : this.props.appt_data.iFamilyMemberId,
            eApptType: "Scheduled",
            iDuration: "15",
            fAppointmentFee: this.props.appt_data.eType === "Initial" ? this.state.selectedDoctor.fFirstConsultFee : this.state.selectedDoctor.fFollowConsultFee,
        }
        console.log(param, "parasm....");

        postApiRequestWithHeaders(data.api_endpoint.book_appointment, param, this.props.user_data.vAccessToken).then(
            data => {
                console.log(data, "data.....");
                showToast(data.message);
                this.props.navigation.reset({
                    index: 0,
                    routes: [{ name: 'CommonPage', params: { type: 'thanks_booking' } }],
                });
                console.log(this.props)
            },
            error => {
                showToast(error);
                console.log(error, 'errorrrrrr');
            },
        );
    }

    getAvailibilityDate = (date) => {
        var today = new Date();
        var someDate = new Date(date);
        if (today.getDate() == someDate.getDate() &&
            someDate.getMonth() == today.getMonth() &&
            someDate.getFullYear() == today.getFullYear()) {
            return (
                <Text style={[styles.memberDesc, { color: colors.geen_txt, fontWeight: 'bold' },]}>Available Today</Text>
            )
        } else {
            return (
                <Text style={[styles.memberDesc, { color: colors.danger, fontWeight: 'bold' },]}>Next Available {'\n'} {moment(date).format("ddd, DD MMM")} </Text>
            )
        }

    }
    onDoctorClick = (item) => {
        console.log(item);
        var param = {
            iUserId: item.iUserId,
            dRmpAvailDate: moment().format("DD-MM-YYYY"),
            eRequestType: 'next'
        }
        console.log(param, "kk");
        postApiRequestWithHeaders(data.api_endpoint.doctor_availibility, param, this.props.user_data.vAccessToken).then(
            data => {
                console.log(data, "data.....");
                this.props.navigation.navigate('RmpAvailabilty', { doctor_data: item, doc_avalibility: data });
                // showToast(data.message);
                // this.props.navigation.reset({
                //     index: 0,
                //     routes: [{ name: 'CommonPage', params: { type: 'thanks_booking' } }],
                // });
                // console.log(this.props)
            },
            error => {
                showToast(error);
                //  console.log(error, 'errorrrrrr');
            },
        );
    }

    _renderMemberList = (item) => {
        return (
            <View style={{ marginTop: 5, paddingRight: 10, paddingLeft: 10, marginBottom: 0 }}>
                <TouchableOpacity >
                    <View style={{ flexDirection: 'row', borderBottomWidth: 1, borderBottomColor: colors.PLACEHOLDER_TEXT, paddingBottom: 0 }}>
                        <View style={{
                            flex: 2,
                            alignItems: 'flex-start',
                            justifyContent: 'center',
                            padding: 10,
                        }}>
                            <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start" }}>
                                <View style={{ marginLeft: 5 }}>
                                    <Image
                                        source={default_user}
                                        source={{
                                            uri: data.profile_picture_url + item.item.vProfilePicture,
                                        }}
                                        style={[styles.profileContainer, {
                                            resizeMode: 'contain',
                                            height: 55, width: 55,
                                            alignSelf: "center",
                                            
                                        }]}
                                    />
                                    <View style={{ marginTop: 5 }}>
                                        <View style={{}}>
                                            <View style={{ alignItems: 'center' }}>
                                                <Text style={[styles.iconText, { marginBottom: 0,}]}>Rs {item.item.fFirstConsultFee}
                                            </Text>
                                            <Text style={[styles.iconText, { marginBottom: 5,fontSize:14, textAlign:'left' }]}>{item.item.iFirstConsultDuration} min call
                                            </Text>
                                            </View>
                                        </View>
                                    </View>
                                </View>
                                <View style={{ alignItems: "flex-start", marginLeft: 10, flexWrap: "wrap" }}>
                                    <Text style={[styles.memberName, { paddingTop: 0, flexWrap: "wrap" }]}>Dr. {item.item.vDoctorName} </Text>
                                    <Text style={styles.memberDesc}>{item.item.vSpecialty} </Text>
                                    <Text style={styles.memberDesc}>{item.item.vQualification} </Text>
                                    <Text style={styles.memberDesc}>Reg. No. {item.item.vRegistrationNo} </Text>
                                </View>
                            </View>
                            <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "flex-start" }}>

                                <View style={{ alignItems: 'center', marginLeft:5}}>
                                    <Button style={styles.nextButtonContainer}
                                        onPress={() => {
                                            this.onDoctorClick(item.item)
                                        }} >
                                        <Text style={styles.nextButton}>Book</Text>
                                    </Button>
                                </View>
                                <View style={{ alignItems: "flex-start", marginLeft: 10 }}>
                                    {item.item.vPracticeArea ? (
                                        <View style={{ flexDirection: "row", justifyContent: "flex-start", alignItems: "flex-start", width: 200 }}>
                                            <Icon name="pin" style={[styles.memberDesc, { color: colors.GREY_SIDEMENU_COLOR }]} />
                                            <Text style={[styles.memberDesc, { color: colors.GREY_SIDEMENU_COLOR }]}>{item.item.vPracticeArea}</Text>
                                        </View>
                                    ) : null}

                                    {item.item.dNextAvailability != "Available Today" ? this.getAvailibilityDate(item.item.dNextAvailability) : <Text style={[styles.memberDesc, { color: colors.geen_txt, fontWeight: 'bold', fontSize:18 },]}>Available Today</Text>}
                                </View>
                            </View>   
                        </View>
                        

                    </View>
                </TouchableOpacity>

            </View>
        )
    }
    render() {
        return (
            <View style={{ flex: 1 }}>
                <Spinner
                    color={colors.sub_theme}
                    visible={this.state.spinner}
                    textContent={''}
                />
                <Container>
                    <HeaderComponent show_headingCenter={true} show_back={true} clickHandler={this.navigator} title={constant.page_titles.AVAILABLE_RMP}></HeaderComponent>
                    {this.state.resulted_rmp.length == 0 && (
                        <View style={{ flex: 1, alignItems: 'center', padding: 20 }}>
                            <Text style={[styles.memberDesc, { textAlign: 'center' }]}>Sorry, No doctor found with selected Treatment Areas</Text>
                        </View>
                    )}
                    <FlatList
                        bounces={false}
                        showsVerticalScrollIndicator={false}
                        data={this.state.resulted_rmp}
                        keyExtractor={item => item.iUserId}     //has to be unique   
                        horizontal={false}
                        renderItem={(item) => this._renderMemberList(item)}
                        onEndReached={(info) => {
                            console.log(JSON.stringify(info), "ending.....");
                            // this.searchDoctor();
                            if (!this.onEndReachedCalledDuringMomentum) {
                                console.log(JSON.stringify(info), "end");
                                this.searchDoctor();
                                this.onEndReachedCalledDuringMomentum = true;
                            }
                        }}
                        onEndReachedThreshold={0.5}
                        onMomentumScrollBegin={() => { this.onEndReachedCalledDuringMomentum = false; }}
                    />

                </Container >


            </View>
        );
    }

    /**
    * Search Practitioner
    */
    searchDoctor = () => {
        console.log(parseInt(this.state.iCurrentPage), parseInt(this.state.iMaxPages), "enterr")
        if (parseInt(this.state.iCurrentPage) < parseInt(this.state.iMaxPages)) {


            console.log("Hit paginitionn...", this.state.iCurrentPage);
            var param = {
                treatments: this.props.appt_data.treatments,
                iCurrentPage: parseInt(this.state.iCurrentPage) + 1,
                fLatitude: this.state.vLat,
                fLongitude: this.state.vLng,
            }
            console.log(param);
            postApiRequestWithHeaders(data.api_endpoint.search_doctors, param, this.props.user_data.vAccessToken).then(
                data => {
                    console.log(data, "data111.....", data.resulted_doctors);
                    var resulted_rmp = [...this.state.resulted_rmp, ...data.resulted_doctors];
                    console.log(resulted_rmp, "chck.....")
                    this.setState({
                        resulted_rmp: [...this.state.resulted_rmp, ...data.resulted_doctors],
                        iCurrentPage: data.iCurrentPage
                    }, () => {
                    })

                },
                error => {
                    showToast(error);
                },
            );
        }
    };
}

function mapStateToProps(state) {
    //console.log(state, "Verify Number state...")
    return {
        user_data: state.user.userData,
        family_member: state.family_member,
        appt_data: state.appointment_booking_data

    }
}
export default connect(mapStateToProps, { setMember })(AvailableRMP);
